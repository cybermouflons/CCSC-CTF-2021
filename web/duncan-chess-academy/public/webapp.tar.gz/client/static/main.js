// custom javascript

$( document ).ready(function() {
  $('#games-table').DataTable({
    "searching": false
  });
});
